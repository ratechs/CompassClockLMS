// controllers/courseController.js
import mongoose from 'mongoose';
import Course from '../models/courseModel.js';
import Material from '../models/meterialModel.js';
import Subject from '../models/subjectModel.js';
import User from '../models/userModel.js';
import enrollment from "../models/enrollmentModel.js";

// Get all courses (no change needed here)
export const getAllCourses = async (req, res) => {
  try {
    const courses = await Course.find()
      .populate({
        path: 'subjects',
        populate: {
          path: 'materials',
          model: 'Material'
        }
      })
      .populate({
        path: 'joinRequests',
        populate: {
          path: 'user',
          model: 'User',
          populate: {
            path: 'institution',
            model: 'Institution',
            select: 'name'
          }
        }
      })
      .populate({
        path: 'created_by',
        model: 'User'
      });

    // Add interested users to each course
    const updatedCourses = await Promise.all(
      courses.map(async (course) => {
        const intrestedCourses = await User.find({
          intrestedCourses: course.id
        }).populate({
          path: 'institution',
        }); // Populate institution name

        return {
          ...course.toObject(),
          interested_users: intrestedCourses,
          interested_users_count: intrestedCourses.length
        };
      })
    );

    res.status(200).json(updatedCourses);

  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: 'Error fetching courses',
      details: error.message
    });
  }
};

// Create a course
export const createCourse = async (req, res) => {
  try {
    console.log(req.body);
    const newCourse = new Course(req.body);
    console.log(newCourse);
    await newCourse.save();

    res.status(201).json({ message: 'Course created successfully', course: newCourse });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Error creating course', details: error.message });
  }
};

// Update a course
export const updateCourse = async (req, res) => {
  try {
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!course) {
      return res.status(404).json({ error: 'Course not found' });
    }

    res.status(200).json({ message: 'Course updated successfully', course });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Error updating course', details: error.message });
  }
};

// Delete a course
export const deleteCourse = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    let deletedCourseDetails = null;

    await session.withTransaction(async () => {
      // Step 1: Find the course
      const course = await Course.findById(req.params.id)
        .populate("subjects")
        .session(session);

      if (!course) {
        const error = new Error("Course not found");
        error.statusCode = 404;
        throw error;
      }

      // Step 2: Capture course details
      deletedCourseDetails = {
        courseName: course.name,
        courseId: course._id.toString(),
      };

      // Step 3: Extract valid subject IDs
      const subjectIds = (course.subjects || [])
        .filter(Boolean)
        .map((subject) => {
          // Handles populated subjects and raw ObjectIds
          return subject._id
            ? subject._id
            : subject;
        });

      // Step 4: Delete materials associated with subjects
      for (const subjectId of subjectIds) {
        await Material.deleteMany({
          subject_id: subjectId,
        }).session(session);
      }

      // Step 5: Delete associated subjects
      for (const subjectId of subjectIds) {
        await Subject.deleteOne({
          _id: subjectId,
        }).session(session);
      }

      // Step 6: Delete the course
      await Course.deleteOne({
        _id: course._id,
      }).session(session);
    });

    // Transaction successful
    return res.status(200).json({
      message: "Course and associated subjects/materials deleted successfully",
      deletedCourse: deletedCourseDetails,
    });

  } catch (error) {
    console.error("Delete Course Error:", error);

    return res.status(error.statusCode || 500).json({
      error: error.statusCode === 404
        ? "Course not found"
        : "Error deleting course",
      details: error.message,
    });

  } finally {
    await session.endSession();
  }
};

// Get details of a specific course (no change needed here)
export const getCourseDetails = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate({
      path: 'subjects',
      populate: {
        path: 'materials',
        model: 'Material'
      }
    }).populate({
      path: 'joinRequests',
      populate: {
        path: 'user',
        model: 'User'
      }
    });
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    res.status(200).json(course);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// Submit a user rating for the course (no change needed here)
export const submitUserRating = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Rating must be between 1 and 5' });
    }

    // Find if user already rated
    const existingIndex = course.ratings.findIndex(
      (r) => r.user.toString() === req.user.id.toString()
    );

    if (existingIndex !== -1) {
      // Update rating & comment
      course.ratings[existingIndex].rating = rating;
      course.ratings[existingIndex].comment = comment;
    } else {
      // Add new rating
      course.ratings.push({ user: req.user.id, rating, comment });
    }

    await course.save();

    return res.status(201).json({ message: 'Rating submitted successfully' });
  } catch (error) {
    return res.status(500).json({ message: error.message, error });
  }
};

// Get average rating for the course (no change needed here)
export const getRating = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    const ratings = course.ratings;
    const totalRatings = ratings.length;
    const averageRating = totalRatings > 0
      ? ratings.reduce((acc, curr) => acc + curr.rating, 0) / totalRatings
      : 0;

    res.status(200).json({ averageRating });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// Get user progress for a course (no change needed here)
export const getCourseProgress = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate('progress.user');
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    const userProgress = course.progress.find(p => p.user._id.toString() === req.user.id);
    if (!userProgress) {
      return res.status(404).json({ message: 'Progress not found for the user in this course' });
    }

    res.json({ progress: userProgress.progress, completedMaterials: userProgress.completedMaterials });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// Update user progress for a course (no change needed here)
export const updateCourseProgress = async (req, res) => {
  try {
    const { materialId } = req.body;
    const courseId = req.params.id;

    const course = await Course.findById(courseId).populate('materials');
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    const userProgress = course.progress.find(p => p.user.toString() === req.user.id);

    // If user progress doesn't exist, create it
    if (!userProgress) {
      const newProgress = {
        user: req.user.id,
        completedMaterials: [materialId],
        progress: (1 / course.materials.length) * 100
      };
      course.progress.push(newProgress);
    } else {
      // If user progress exists, update it
      if (!userProgress.completedMaterials.includes(materialId)) {
        userProgress.completedMaterials.push(materialId);
        userProgress.progress = (userProgress.completedMaterials.length / course.materials.length) * 100;
      }
    }

    await course.save();
    res.status(200).json({ message: 'Progress updated successfully', progress: userProgress.progress });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

export const getCoursesByType = async (req, res) => {
  try {
    const { type } = req.params;

    const allowedTypes = ['public', 'private'];
    if (!allowedTypes.includes(type)) {
      return res.status(400).json({ message: 'Invalid course type' });
    }

    const courses = await Course.find({ course_type: type }).populate({
      path: 'subjects',
      populate: {
        path: 'materials',
        model: 'Material'
      }
    }).populate({
      path: 'course_institution',
      populate: {
        path: 'institution',
        model: 'Institution'
      }
    });

    res.status(200).json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error fetching courses by type', details: error.message });
  }
};

export const getCourseByJoinCode = async (req, res) => {
  try {
    const { joinCode } = req.params;

    const course = await Course.findOne({ join_code: joinCode }).populate({
      path: 'subjects',
      populate: {
        path: 'materials',
        model: 'Material'
      }
    }).populate({
      path: 'course_institution',
      populate: {
        path: 'institution',
        model: 'Institution'
      }
    });

    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    res.status(200).json(course);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error fetching course by join code', details: error.message });
  }
};

// Removed notification for requestCourseJoin as per your latest request
export const requestCourseJoin = async (req, res) => {
  try {
    const { joinCode, userId } = req.body;

    // -----------------------------------------
    // VALIDATION
    // -----------------------------------------

    if (!joinCode || !userId) {
      return res.status(400).json({
        message: "Join code and userId are required",
      });
    }

    // -----------------------------------------
    // FIND COURSE
    // -----------------------------------------

    const course = await Course.findOne({
      join_code: joinCode.trim(),
    });

    if (!course) {
      return res.status(404).json({
        message: "Course not found",
      });
    }

    // -----------------------------------------
    // FIND USER
    // -----------------------------------------

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        message: "Requesting user not found",
      });
    }

    // -----------------------------------------
    // CHECK EXISTING REQUEST
    // -----------------------------------------

    const existingRequest = course.joinRequests.find(
      (joinReq) =>
        joinReq.user &&
        joinReq.user.toString() === userId.toString()
    );

    // -----------------------------------------
    // ALREADY APPROVED
    // -----------------------------------------

    if (existingRequest?.status === "approved") {
      return res.status(400).json({
        message: "You are already enrolled in this course",
        status: "approved",
      });
    }

    // -----------------------------------------
    // REQUEST ALREADY PENDING
    // -----------------------------------------

    if (existingRequest?.status === "pending") {
      return res.status(400).json({
        message: "Your request is already pending",
        status: "pending",
      });
    }

    // -----------------------------------------
    // PREVIOUSLY REJECTED
    // -----------------------------------------
    // Allow the student to request again.
    // Instead of pushing another request, update
    // the previous rejected request.

    if (existingRequest?.status === "rejected") {
      existingRequest.status = "pending";

      await course.save();

      return res.status(200).json({
        message: "Course join request submitted again",
        status: "requested",
      });
    }

    // -----------------------------------------
    // NEW REQUEST
    // -----------------------------------------

    course.joinRequests.push({
      user: userId,
      status: "pending",
    });

    await course.save();

    return res.status(200).json({
      message: "Join request submitted successfully",
      status: "requested",
    });
  } catch (error) {
    console.error("requestCourseJoin error:", error);

    return res.status(500).json({
      message: "Error requesting course join",
      error: error.message,
    });
  }
};
export const getJoinRequestsForCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate({
        path: 'joinRequests.user',
        select: 'username email role institution',
        populate: {
          path: 'institution',
          model: 'Institution',
          select: 'name address type', // pick fields you actually need
        },
      })
      .populate({
        path: 'course_institution',
        populate: {
          path: 'institution',
          model: 'Institution',
        },
      });

    if (!course) return res.status(404).json({ message: 'Course not found' });

    // Optional: Only allow creator/admin to view
    if (req.user.id !== course.creator?.toString() && !req.user.isAdmin) {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    res.status(200).json({ joinRequests: course.joinRequests });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching join requests', error });
  }
};


export const handleJoinRequest = async (req, res) => {
  try {
    const { courseId, userId, action } = req.body;

    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: 'Course not found' });

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (!user.isActive) {
      return res.status(403).json({ message: 'User is not active' });
    }

    const request = course.joinRequests.find((r) => r.user.toString() === userId);
    if (!request) return res.status(404).json({ message: 'Join request not found' });

    if (!['approved', 'rejected'].includes(action)) {
      return res.status(400).json({ message: 'Invalid action' });
    }

    request.status = action;

    await course.save();

    // --- Push Notification Logic for Handle Join Request (Approved/Rejected) ---
    // Notify the requesting user about the status of their request

    res.status(200).json({ message: `Request ${action} successfully` });
  } catch (error) {
    console.error("Join request error:", error);
    res.status(500).json({ message: 'Error handling request', error: error.message });
    console.log(`Handling join request: courseId=${courseId}, userId=${userId}, action=${action}`);

  }
};

export const getAllJoinRequests = async (req, res) => {
  try {
    const allCourses = await Course.find()
      .populate('joinRequests.user', 'name email'); // Convert documents to plain JS objects

    const allJoinRequests = allCourses.flatMap(course =>
      course.joinRequests.map(req => ({
        course: course._id,
        user: req.user,
        status: req.status,
        requestedAt: req.requestedAt
      }))
    );

    res.status(200).json(allJoinRequests); // Send the response
  } catch (error) {
    res.status(500).json({ message: 'Error fetching join requests', error }); // Handle errors
  }
};

export const getCountofJoinRequestsByCreator = async (req, res) => {
  try {
    const { creatorId } = req.params;

    const courses = await Course.find({ created_by: creatorId });

    const allJoinRequests = courses.flatMap(course =>
      course.joinRequests.map(req => ({
        course: course._id,
        user: req.user,
        status: req.status,
        requestedAt: req.requestedAt
      }))
    );

    res.status(200).json(allJoinRequests);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching join request count', error });
  }
};

export const enrollFreeCourse = async (req, res) => {
  try {
    const userId = req.user?._id || req.body.userId;
    const { courseId } = req.body;

    if (!userId || !courseId) {
      return res.status(400).json({
        message: 'userId and courseId are required'
      });
    }

    const course = await Course.findById(courseId);

    if (!course) {
      return res.status(404).json({
        message: 'Course not found'
      });
    }

    // -----------------------------
    // MUST BE FREE
    // -----------------------------

    if (course.is_paidCourse) {
      return res.status(400).json({
        message: 'This is a paid course'
      });
    }

    // -----------------------------
    // PRIVATE COURSE
    // -----------------------------

    if (course.course_type === 'private') {
      const joinRequest = course.joinRequests.find(
        (request) =>
          request.user &&
          request.user.toString() === userId.toString()
      );

      if (!joinRequest || joinRequest.status !== 'approved') {
        return res.status(403).json({
          message: 'You must be approved to join this private course'
        });
      }
    }

    // -----------------------------
    // CHECK EXISTING ENROLLMENT
    // -----------------------------

    const existingEnrollment =
      await Enrollment.findOne({
        user: userId,
        course: courseId
      });

    if (existingEnrollment) {
      return res.status(400).json({
        message: 'You are already enrolled in this course',
        enrollment: existingEnrollment
      });
    }

    // -----------------------------
    // CREATE ENROLLMENT
    // -----------------------------

    const enrollment = await Enrollment.create({
      user: userId,
      course: courseId,
      enrollmentType: 'free',
      status: 'active',
      enrolledAt: new Date()
    });

    return res.status(201).json({
      message: 'Successfully enrolled in free course',
      enrollment
    });

  } catch (error) {
    console.error('Free enrollment error:', error);

    return res.status(500).json({
      message: 'Unable to enroll in course',
      error: error.message
    });
  }
};


export const checkCourseAccess = async (req, res) => {
  try {
    const { courseId } = req.params;

    const userId = req.user?._id || req.user?.id;

    if (!userId) {
      return res.status(401).json({
        message: "User not authenticated",
        hasAccess: false
      });
    }

    if (!courseId) {
      return res.status(400).json({
        message: "Course ID is required",
        hasAccess: false
      });
    }

    // Check user
    const user = await User.findById(userId).select("courses");

    if (!user) {
      return res.status(404).json({
        message: "User not found",
        hasAccess: false
      });
    }

    // Check whether course exists
    const course = await Course.findById(courseId).select("_id");

    if (!course) {
      return res.status(404).json({
        message: "Course not found",
        hasAccess: false
      });
    }

    // Check User.courses
    const hasAccess = user.courses?.some(
      id => id.toString() === courseId.toString()
    );

    return res.status(200).json({
      hasAccess: !!hasAccess,
      courseId,
      userId
    });

  } catch (error) {
    console.error("Check course access error:", error);

    return res.status(500).json({
      message: "Error checking course access",
      hasAccess: false,
      error: error.message
    });
  }
};

